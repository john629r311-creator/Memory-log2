package com.memoryrecall.app;
import android.app.usage.*;
import android.content.*;
import android.os.*;
import java.io.*;
import java.text.*;
import java.util.*;
public final class ActivityLog {
 static final long PERIOD=30L*60*1000;
 static String report(Context ctx,long end){
  long start=end-PERIOD; DateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);
  StringBuilder sb=new StringBuilder("Memory Recall — Activity report\n").append(df.format(new Date(start))).append(" to ").append(df.format(new Date(end))).append("\n\n");
  UsageStatsManager mgr=(UsageStatsManager)ctx.getSystemService(Context.USAGE_STATS_SERVICE);
  UsageEvents events=mgr.queryEvents(start,end); UsageEvents.Event e=new UsageEvents.Event();int count=0;
  while(events.hasNextEvent()){events.getNextEvent(e);int t=e.getEventType();
   if(t==UsageEvents.Event.ACTIVITY_RESUMED||t==UsageEvents.Event.ACTIVITY_PAUSED||t==UsageEvents.Event.SCREEN_INTERACTIVE||t==UsageEvents.Event.SCREEN_NON_INTERACTIVE){
    String type=t==UsageEvents.Event.ACTIVITY_RESUMED?"App opened":t==UsageEvents.Event.ACTIVITY_PAUSED?"App left":t==UsageEvents.Event.SCREEN_INTERACTIVE?"Screen active":"Screen inactive";
    sb.append(df.format(new Date(e.getTimeStamp()))).append(" — ").append(type).append(" — ").append(e.getPackageName()).append("\n");count++;
   }
  }
  if(count==0)sb.append("No available events; check Android Usage Access.\n");
  sb.append("\nKeyboard sessions (no typed content):\n").append(SessionStore.between(ctx,start,end));
  return sb.append("\nEvents: ").append(count).append("\n").toString();
 }
 static File save(Context ctx,long end)throws IOException {
  File dir=new File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"MemoryRecallLogs");
  if(!dir.exists()&&!dir.mkdirs())throw new IOException("Cannot create log directory");
  String name="log-"+new SimpleDateFormat("MM-dd-yy-hh-mma",Locale.US).format(new Date(end)).toLowerCase(Locale.US)+".txt";
  File file=new File(dir,name);
  try(Writer writer=new OutputStreamWriter(new FileOutputStream(file),"UTF-8")){writer.write(report(ctx,end));}
  return file;
 }
}
