package com.memoryrecall.app;
import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
public class MainActivity extends Activity {
 private LinearLayout page;
 private boolean agreed(){return getSharedPreferences("settings",MODE_PRIVATE).getBoolean("consent",false);}
 @Override public void onCreate(Bundle b){super.onCreate(b);render();}
 private void label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.WHITE);t.setPadding(12,14,12,14);page.addView(t);}
 private void button(String s,Runnable r){Button b=new Button(this);b.setText(s);page.addView(b);b.setOnClickListener(v->r.run());}
 private void render(){ScrollView scroll=new ScrollView(this);page=new LinearLayout(this);page.setOrientation(1);page.setPadding(24,30,24,24);page.setBackgroundColor(Color.rgb(14,24,42));scroll.addView(page);setContentView(scroll);
 label("MEMORY RECALL",28);label("On-device activity & keyboard session journal",16);
 if(!agreed()){
 label("This app records available application and screen activity, plus the start and end times of sessions using its optional keyboard. It does NOT save typed characters, passwords, messages, or clipboard contents. Reports are written to the app-specific Documents/MemoryRecallLogs folder about every 30 minutes, subject to Android scheduling. No data is sent online. You may stop monitoring here at any time. Uninstalling may delete app-specific logs.",15);
 CheckBox cb=new CheckBox(this);cb.setText("I understand and agree to local activity recording.");cb.setTextColor(Color.WHITE);page.addView(cb);
 button("Agree and continue",()->{if(cb.isChecked()){getSharedPreferences("settings",MODE_PRIVATE).edit().putBoolean("consent",true).apply();LogJobService.schedule(this);render();}else Toast.makeText(this,"Consent required",Toast.LENGTH_SHORT).show();});return;
 }
 label("● ACTIVITY RECORDING ENABLED",18);
 label("Files: Android/data/com.memoryrecall.app/files/Documents/MemoryRecallLogs/",14);
 button("Grant Usage Access",()->startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)));
 button("Enable Memory Recall Keyboard",()->startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
 button("Choose Keyboard",()->{InputMethodManager m=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);m.showInputMethodPicker();});
 button("Save 30-minute report now",()->{try{ActivityLog.save(this,System.currentTimeMillis());Toast.makeText(this,"Report saved to local folder",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Save failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}});
 button("Stop monitoring and withdraw consent",()->{LogJobService.cancel(this);getSharedPreferences("settings",MODE_PRIVATE).edit().putBoolean("consent",false).apply();render();});
 button("Delete keyboard session history",()->{SessionStore.clear(this);Toast.makeText(this,"Session history cleared",Toast.LENGTH_SHORT).show();});
 label("No log viewer is included. Use a compatible file manager to access the app-specific directory. On some Android versions this folder is restricted.",13);
 }
}
