package com.memoryrecall.app;

import android.inputmethodservice.InputMethodService;
import android.graphics.Color;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.EditorInfo;
import android.widget.*;

/** Standard user-selected IME. Never persists typed characters or reads editor contents. */
public class MemoryKeyboard extends InputMethodService {
 private long started;
 private LinearLayout root;
 private TextView recordingDot;
 private boolean shifted=false;
 private int chars=0,deletions=0,spaces=0,enters=0;
 private boolean sensitive=false;
 @Override public View onCreateInputView() {
  root=new LinearLayout(this);root.setOrientation(1);root.setPadding(5,8,5,8);root.setBackgroundColor(Color.rgb(28,35,51));
  // Minimal status: blue when key-count recording is enabled; gray for sensitive fields.
  LinearLayout statusRow=new LinearLayout(this);
  statusRow.setGravity(android.view.Gravity.RIGHT | android.view.Gravity.CENTER_VERTICAL);
  root.addView(statusRow,new LinearLayout.LayoutParams(-1,28));
  recordingDot=new TextView(this);
  recordingDot.setText("●");recordingDot.setTextSize(15);
  recordingDot.setGravity(android.view.Gravity.CENTER);
  recordingDot.setContentDescription("Keyboard activity recording status");
  recordingDot.setPadding(8,0,12,0);
  statusRow.addView(recordingDot,new LinearLayout.LayoutParams(48,28));
  recordingDot.setOnClickListener(v->android.widget.Toast.makeText(this,
    sensitive ? "Recording off for sensitive input" : "Recording key counts only; typed text is not saved",
    android.widget.Toast.LENGTH_LONG).show());
  updateRecordingDot();
  addRow("qwertyuiop");addRow("asdfghjkl");addRow("zxcvbnm");
  LinearLayout actions=new LinearLayout(this);root.addView(actions);
  key(actions,"⇧",()->{shifted=!shifted;});
  key(actions,"123",()->{ /* letters remain available; symbols provided below */ });
  key(actions,",",()->type(","));key(actions,"SPACE",()->type(" "));
  key(actions,".",()->type("."));
  key(actions,"⌫",()->{InputConnection ic=getCurrentInputConnection();if(ic!=null){ic.deleteSurroundingText(1,0);if(!sensitive)deletions++;}});
  key(actions,"↵",()->{InputConnection ic=getCurrentInputConnection();if(ic!=null){ic.performEditorAction(EditorInfo.IME_ACTION_DONE);if(!sensitive)enters++;}});
  LinearLayout symbols=new LinearLayout(this);root.addView(symbols);
  for(String s:new String[]{"1","2","3","4","5","6","7","8","9","0","@","?","!"})key(symbols,s,()->type(s));
  return root;
 }
 private void updateRecordingDot(){
  if(recordingDot==null)return;
  recordingDot.setTextColor(sensitive ? Color.rgb(145,150,160) : Color.rgb(50,145,255));
  recordingDot.setContentDescription(sensitive ? "Recording off for sensitive input" : "Recording key counts active; no text saved");
 }
 private void addRow(String letters){LinearLayout row=new LinearLayout(this);root.addView(row);for(char c:letters.toCharArray()){String s=String.valueOf(c);key(row,s,()->type(shifted?s.toUpperCase():s));}}
 private void key(LinearLayout row,String title,Runnable action){Button b=new Button(this);b.setText(title);b.setTextSize(13);b.setAllCaps(false);b.setMinWidth(0);b.setMinimumWidth(0);b.setPadding(0,0,0,0);row.addView(b,new LinearLayout.LayoutParams(0,56, title.equals("SPACE")?3:1));b.setOnClickListener(v->action.run());}
 private void type(String text){InputConnection ic=getCurrentInputConnection();if(ic!=null){ic.commitText(text,1);if(!sensitive){if(" ".equals(text))spaces++;else chars+=text.length();}}}
 @Override public void onStartInputView(EditorInfo info,boolean restarting){super.onStartInputView(info,restarting);started=System.currentTimeMillis();chars=deletions=spaces=enters=0;
  int variation=info.inputType & android.text.InputType.TYPE_MASK_VARIATION;
  int klass=info.inputType & android.text.InputType.TYPE_MASK_CLASS;
  sensitive=(klass==android.text.InputType.TYPE_CLASS_TEXT && (variation==android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD || variation==android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD || variation==android.text.InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) || (klass==android.text.InputType.TYPE_CLASS_NUMBER && variation==android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);updateRecordingDot();}
 @Override public void onFinishInputView(boolean finishingInput){if(started>0){if(!sensitive)SessionStore.add(this,started,System.currentTimeMillis(),chars,deletions,spaces,enters);started=0;}super.onFinishInputView(finishingInput);}
}
