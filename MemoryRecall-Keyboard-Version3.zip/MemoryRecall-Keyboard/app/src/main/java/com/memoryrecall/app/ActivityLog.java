package com.memoryrecall.app;
import android.app.usage.*;
import android.content.*;
import android.os.*;
import android.net.Uri;
import android.provider.DocumentsContract;
import java.io.*;
import java.text.*;
import java.util.*;
public final class ActivityLog {
 static final long PERIOD=30L*60*1000;
 static String report(Context ctx,long end){
  long start=end-PERIOD; DateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);
  StringBuilder sb=new StringBuilder("Memory Recall — Activity report\n").append(df.format(new Date(start))).append(" to ").append(df.format(new Date(end))).append("\n\n");
  UsageStatsManager mgr=(UsageStatsManager)ctx.getSystemService(Context.USAGE_STATS_SERVICE);
  UsageEvents events=mgr.queryEvents(start,end); UsageEvents.Event e=new UsageEvents.Event();int count=0;
  while(events.hasNextEvent()){events.getNextEvent(e);int t=e.getEventType();
   if(t==UsageEvents.Event.ACTIVITY_RESUMED||t==UsageEvents.Event.ACTIVITY_PAUSED||t==UsageEvents.Event.SCREEN_INTERACTIVE||t==UsageEvents.Event.SCREEN_NON_INTERACTIVE){
    String type=t==UsageEvents.Event.ACTIVITY_RESUMED?"App opened":t==UsageEvents.Event.ACTIVITY_PAUSED?"App left":t==UsageEvents.Event.SCREEN_INTERACTIVE?"Screen active":"Screen inactive";
    sb.append(df.format(new Date(e.getTimeStamp()))).append(" — ").append(type).append(" — ").append(e.getPackageName()).append("\n");count++;
   }
  }
  if(count==0)sb.append("No available events; check Android Usage Access.\n");
  sb.append("\nKeyboard sessions (no typed content):\n").append(SessionStore.between(ctx,start,end));
  return sb.append("\nEvents: ").append(count).append("\n").toString();
 }
 static File save(Context ctx,long end)throws IOException {
  File dir=new File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"MemoryRecallLogs");
  if(!dir.exists()&&!dir.mkdirs())throw new IOException("Cannot create log directory");
  String name="log-"+new SimpleDateFormat("MM-dd-yy-hh-mma",Locale.US).format(new Date(end)).toLowerCase(Locale.US)+".txt";
  File file=new File(dir,name);
  try(Writer writer=new OutputStreamWriter(new FileOutputStream(file),"UTF-8")){writer.write(report(ctx,end));}
  return file;
 }
 static boolean hasChosenFolder(Context ctx){return !ctx.getSharedPreferences("settings",Context.MODE_PRIVATE).getString("log_tree","").isEmpty();}
 static void saveToChosenFolder(Context ctx,long end)throws IOException {
  String raw=ctx.getSharedPreferences("settings",Context.MODE_PRIVATE).getString("log_tree","");
  if(raw.isEmpty())throw new IOException("Choose a log folder first");
  Uri tree=Uri.parse(raw);
  String name="log-"+new SimpleDateFormat("MM-dd-yy-hh-mma",Locale.US).format(new Date(end)).toLowerCase(Locale.US)+".txt";
  Uri parent=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
  Uri doc=DocumentsContract.createDocument(ctx.getContentResolver(),parent,"text/plain",name);
  if(doc==null)throw new IOException("Cannot create file in selected folder");
  try(OutputStream out=ctx.getContentResolver().openOutputStream(doc,"wt")){
   if(out==null)throw new IOException("Cannot open selected folder for writing");
   out.write(report(ctx,end).getBytes("UTF-8"));
  }
 }
 static String saveReport(Context ctx,long end)throws IOException {
  if(hasChosenFolder(ctx)){saveToChosenFolder(ctx,end);return "Report saved to chosen folder";}
  save(ctx,end);return "Report saved to app-private folder";
 }
 static int exportExisting(Context ctx)throws IOException {
  if(!hasChosenFolder(ctx))throw new IOException("Choose a folder first");
  File dir=new File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"MemoryRecallLogs");
  File[] files=dir.listFiles();if(files==null)return 0;
  Uri tree=Uri.parse(ctx.getSharedPreferences("settings",Context.MODE_PRIVATE).getString("log_tree",""));
  Uri parent=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
  int copied=0;
  for(File file:files){if(!file.isFile()||!file.getName().endsWith(".txt"))continue;
   Uri doc=DocumentsContract.createDocument(ctx.getContentResolver(),parent,"text/plain",file.getName());
   if(doc==null)throw new IOException("Could not create "+file.getName());
   try(InputStream in=new FileInputStream(file);OutputStream out=ctx.getContentResolver().openOutputStream(doc,"wt")){
    if(out==null)throw new IOException("Cannot write "+file.getName());
    byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
   }copied++;
  }return copied;
 }
}
