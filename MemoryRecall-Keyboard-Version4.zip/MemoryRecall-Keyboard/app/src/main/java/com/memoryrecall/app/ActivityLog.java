package com.memoryrecall.app;
import android.app.usage.*;
import android.content.*;
import android.os.*;
import android.net.Uri;
import android.provider.DocumentsContract;
import java.io.*;
import java.text.*;
import java.util.*;
public final class ActivityLog {
 static final long PERIOD=30L*60*1000;
 static String report(Context ctx,long end){
  long start=end-PERIOD; DateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);
  StringBuilder sb=new StringBuilder("Memory Recall — Activity report\n").append(df.format(new Date(start))).append(" to ").append(df.format(new Date(end))).append("\n\n");
  UsageStatsManager mgr=(UsageStatsManager)ctx.getSystemService(Context.USAGE_STATS_SERVICE);
  UsageEvents events=mgr.queryEvents(start,end); UsageEvents.Event e=new UsageEvents.Event();int count=0;
  String lastPackage=""; long lastForeground=0;
  while(events.hasNextEvent()){
   events.getNextEvent(e);int t=e.getEventType();
   String message=null;String pkg=e.getPackageName();
   if(t==UsageEvents.Event.ACTIVITY_RESUMED){
    // Avoid repeated "opened" lines for a single app's internal screen changes.
    if(pkg!=null&&(!pkg.equals(lastPackage)||e.getTimeStamp()-lastForeground>120000)){
     message=appName(ctx,pkg)+" opened";
    }
    lastPackage=pkg==null?"":pkg;lastForeground=e.getTimeStamp();
   }else if(t==UsageEvents.Event.SCREEN_INTERACTIVE){message="Screen turned on";}
   else if(t==UsageEvents.Event.SCREEN_NON_INTERACTIVE){message="Screen turned off";lastPackage="";}
   if(message!=null){sb.append(df.format(new Date(e.getTimeStamp()))).append(" — ").append(message).append("\n");count++;}
  }
  if(count==0)sb.append("No available events; check Android Usage Access.\n");
  sb.append("\nKeyboard sessions (no typed content):\n").append(SessionStore.between(ctx,start,end));
  return sb.append("\nEvents: ").append(count).append("\n").toString();
 }
 private static String appName(Context ctx,String pkg){
  if(pkg==null||pkg.isEmpty())return "Unknown app";
  // Friendly names for common apps, even if Android limits package visibility.
  switch(pkg){
   case "com.openai.chatgpt":return "ChatGPT";
   case "com.google.android.youtube":return "YouTube";
   case "com.android.chrome":return "Chrome";
   case "com.google.android.gm":return "Gmail";
   case "com.whatsapp":return "WhatsApp";
   case "com.facebook.katana":return "Facebook";
   case "com.instagram.android":return "Instagram";
   case "com.google.android.apps.messaging":return "Google Messages";
  }
  try{
   android.content.pm.PackageManager pm=ctx.getPackageManager();
   CharSequence label=pm.getApplicationLabel(pm.getApplicationInfo(pkg,0));
   if(label!=null&&label.length()>0)return label.toString();
  }catch(Exception ignored){}
  return pkg; // Keep exact package name when the app label is unavailable.
 }
 static File save(Context ctx,long end)throws IOException {
  File dir=new File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"MemoryRecallLogs");
  if(!dir.exists()&&!dir.mkdirs())throw new IOException("Cannot create log directory");
  String name="log-"+new SimpleDateFormat("MM-dd-yy-hh-mma",Locale.US).format(new Date(end)).toLowerCase(Locale.US)+".txt";
  File file=new File(dir,name);
  try(Writer writer=new OutputStreamWriter(new FileOutputStream(file),"UTF-8")){writer.write(report(ctx,end));}
  return file;
 }
 static boolean hasChosenFolder(Context ctx){return !ctx.getSharedPreferences("settings",Context.MODE_PRIVATE).getString("log_tree","").isEmpty();}
 static void saveToChosenFolder(Context ctx,long end)throws IOException {
  String raw=ctx.getSharedPreferences("settings",Context.MODE_PRIVATE).getString("log_tree","");
  if(raw.isEmpty())throw new IOException("Choose a log folder first");
  Uri tree=Uri.parse(raw);
  String name="log-"+new SimpleDateFormat("MM-dd-yy-hh-mma",Locale.US).format(new Date(end)).toLowerCase(Locale.US)+".txt";
  Uri parent=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
  Uri doc=DocumentsContract.createDocument(ctx.getContentResolver(),parent,"text/plain",name);
  if(doc==null)throw new IOException("Cannot create file in selected folder");
  try(OutputStream out=ctx.getContentResolver().openOutputStream(doc,"wt")){
   if(out==null)throw new IOException("Cannot open selected folder for writing");
   out.write(report(ctx,end).getBytes("UTF-8"));
  }
 }
 static String saveReport(Context ctx,long end)throws IOException {
  if(hasChosenFolder(ctx)){saveToChosenFolder(ctx,end);return "Report saved to chosen folder";}
  save(ctx,end);return "Report saved to app-private folder";
 }
 static int exportExisting(Context ctx)throws IOException {
  if(!hasChosenFolder(ctx))throw new IOException("Choose a folder first");
  File dir=new File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"MemoryRecallLogs");
  File[] files=dir.listFiles();if(files==null)return 0;
  Uri tree=Uri.parse(ctx.getSharedPreferences("settings",Context.MODE_PRIVATE).getString("log_tree",""));
  Uri parent=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
  int copied=0;
  for(File file:files){if(!file.isFile()||!file.getName().endsWith(".txt"))continue;
   Uri doc=DocumentsContract.createDocument(ctx.getContentResolver(),parent,"text/plain",file.getName());
   if(doc==null)throw new IOException("Could not create "+file.getName());
   try(InputStream in=new FileInputStream(file);OutputStream out=ctx.getContentResolver().openOutputStream(doc,"wt")){
    if(out==null)throw new IOException("Cannot write "+file.getName());
    byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
   }copied++;
  }return copied;
 }
}
