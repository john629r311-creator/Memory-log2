package com.memoryrecall.app;
import android.app.job.*;
import android.content.*;
import java.util.concurrent.*;
public class LogJobService extends JobService {
 private final ExecutorService executor=Executors.newSingleThreadExecutor();
 @Override public boolean onStartJob(JobParameters params){
  executor.execute(()->{try{
   if(getSharedPreferences("settings",MODE_PRIVATE).getBoolean("consent",false))ActivityLog.saveReport(this,System.currentTimeMillis());
  }catch(Exception ignored){}finally{jobFinished(params,false);}});return true;
 }
 @Override public boolean onStopJob(JobParameters params){return true;}
 static void schedule(Context ctx){JobScheduler scheduler=(JobScheduler)ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE);
  scheduler.schedule(new JobInfo.Builder(3026,new ComponentName(ctx,LogJobService.class)).setPeriodic(30L*60*1000).setPersisted(true).build());}
 static void cancel(Context ctx){((JobScheduler)ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE)).cancel(3026);}
}
