package com.memoryrecall.app;
import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.os.Bundle;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
public class MainActivity extends Activity {
 private static final int PICK_FOLDER=1207;
 private LinearLayout page;
 @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
  super.onActivityResult(requestCode,resultCode,data);
  if(requestCode==PICK_FOLDER&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
   Uri uri=data.getData();
   try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
    getSharedPreferences("settings",MODE_PRIVATE).edit().putString("log_tree",uri.toString()).apply();
    Toast.makeText(this,"Log folder selected",Toast.LENGTH_LONG).show();render();
   }catch(SecurityException e){Toast.makeText(this,"Folder permission failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
  }
 }
 private boolean agreed(){return getSharedPreferences("settings",MODE_PRIVATE).getBoolean("consent",false);}
 @Override public void onCreate(Bundle b){super.onCreate(b);render();}
 private void label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.WHITE);t.setPadding(12,14,12,14);page.addView(t);}
 private void button(String s,Runnable r){Button b=new Button(this);b.setText(s);page.addView(b);b.setOnClickListener(v->r.run());}
 private void render(){ScrollView scroll=new ScrollView(this);page=new LinearLayout(this);page.setOrientation(1);page.setPadding(24,30,24,24);page.setBackgroundColor(Color.rgb(14,24,42));scroll.addView(page);setContentView(scroll);
 label("MEMORY RECALL",28);label("On-device activity & keyboard session journal",16);
 if(!agreed()){
 label("This app records available application and screen activity, plus the start and end times of sessions using its optional keyboard. It does NOT save typed characters, passwords, messages, or clipboard contents. Reports are written to the app-specific Documents/MemoryRecallLogs folder about every 30 minutes, subject to Android scheduling. No data is sent online. You may stop monitoring here at any time. Uninstalling may delete app-specific logs.",15);
 CheckBox cb=new CheckBox(this);cb.setText("I understand and agree to local activity recording.");cb.setTextColor(Color.WHITE);page.addView(cb);
 button("Agree and continue",()->{if(cb.isChecked()){getSharedPreferences("settings",MODE_PRIVATE).edit().putBoolean("consent",true).apply();LogJobService.schedule(this);render();}else Toast.makeText(this,"Consent required",Toast.LENGTH_SHORT).show();});return;
 }
 label("● ACTIVITY RECORDING ENABLED",18);
 label(ActivityLog.hasChosenFolder(this)?"Log destination: your selected folder":"Log destination: app-private folder (Android/data, may be inaccessible)",14);
 button("Choose Log Folder",()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK_FOLDER);});
 button("Export Existing Logs to Chosen Folder",()->{try{int count=ActivityLog.exportExisting(this);Toast.makeText(this,"Exported "+count+" existing log(s)",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}});
 button("Grant Usage Access",()->startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)));
 button("Enable Memory Recall Keyboard",()->startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
 button("Choose Keyboard",()->{InputMethodManager m=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);m.showInputMethodPicker();});
 button("Save 30-minute report now",()->{try{String destination=ActivityLog.saveReport(this,System.currentTimeMillis());Toast.makeText(this,destination,Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Save failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}});
 button("Stop monitoring and withdraw consent",()->{LogJobService.cancel(this);getSharedPreferences("settings",MODE_PRIVATE).edit().putBoolean("consent",false).apply();render();});
 button("Delete keyboard session history",()->{SessionStore.clear(this);Toast.makeText(this,"Session history cleared",Toast.LENGTH_SHORT).show();});
 label("Choose Documents or a subfolder in the Android folder picker. Future automatic reports use that folder when permission remains available. Existing private reports can be exported. If folder access is revoked, automatic saves may fail until you choose again. No log viewer is included.",13);
 }
}
