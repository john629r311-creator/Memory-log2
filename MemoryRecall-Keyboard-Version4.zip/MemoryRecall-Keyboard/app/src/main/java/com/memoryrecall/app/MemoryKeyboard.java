package com.memoryrecall.app;

import android.inputmethodservice.InputMethodService;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.LinearLayout;
import android.widget.TextView;

/** User-selected keyboard. Only aggregate key counts are stored, after consent; never typed text. */
public class MemoryKeyboard extends InputMethodService {
 private LinearLayout root;
 private TextView indicator;
 private long started;
 private int chars, deletions, spaces, enters;
 private boolean shifted, symbols, sensitive;
 private static final int BACK=0xff20232b, KEY=0xff444953, SPECIAL=0xff303741, TEXT=Color.WHITE;
 private int dp(float value){return (int)(getResources().getDisplayMetrics().density*value+0.5f);}
 private boolean consent(){return getSharedPreferences("settings",MODE_PRIVATE).getBoolean("consent",false);}
 private boolean recording(){return consent()&&!sensitive;}
 private GradientDrawable background(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(7));return d;}
 @Override public View onCreateInputView(){
  root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(2),dp(4),dp(2),dp(6));root.setBackgroundColor(BACK);
  render();return root;
 }
 private void render(){
  if(root==null)return;
  root.removeAllViews();
  LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);root.addView(top,new LinearLayout.LayoutParams(-1,dp(30)));
  TextView title=new TextView(this);title.setText(symbols?"Symbols":"Memory Recall");title.setTextSize(12);title.setTextColor(0xffadb4c1);title.setGravity(Gravity.CENTER_VERTICAL);title.setPadding(dp(10),0,0,0);
  top.addView(title,new LinearLayout.LayoutParams(0,-1,1));
  indicator=new TextView(this);indicator.setText("●");indicator.setTextSize(15);indicator.setGravity(Gravity.CENTER);indicator.setContentDescription(recording()?"Activity counts enabled":"Activity counts disabled");indicator.setTextColor(recording()?0xff3998ff:0xff7a8290);
  top.addView(indicator,new LinearLayout.LayoutParams(dp(38),-1));
  indicator.setOnClickListener(v->android.widget.Toast.makeText(this,recording()?"Activity counts only; no typed text is saved":"Recording is off",android.widget.Toast.LENGTH_SHORT).show());
  if(symbols){
   addRow(new String[]{"1","2","3","4","5","6","7","8","9","0"},null);
   addRow(new String[]{"@","#","$","%","&","-","+","(",")","/"},null);
   addRow(new String[]{"*","\"",":",";","!","?","'","⌫"},null);
  }else{
   addRow(new String[]{"1","2","3","4","5","6","7","8","9","0"},null);
   addRow(new String[]{"q","w","e","r","t","y","u","i","o","p"},null);
   addRow(new String[]{"a","s","d","f","g","h","j","k","l"},null);
   addRow(new String[]{"⇧","z","x","c","v","b","n","m","⌫"},null);
  }
  addRow(new String[]{symbols?"ABC":"?123",",","☻","space",".","↵"},new float[]{1.35f,.75f,.75f,4.6f,.75f,1.25f});
 }
 private void addRow(String[] keys,float[] weights){
  LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER);root.addView(row,new LinearLayout.LayoutParams(-1,dp(55)));
  for(int i=0;i<keys.length;i++){
   final String key=keys[i];
   TextView b=new TextView(this);b.setText(key.equals("space")?"English (US)":(shifted&&!symbols&&key.length()==1&&Character.isLetter(key.charAt(0))?key.toUpperCase():key));
   b.setTextSize(key.equals("space")?12:(key.length()>2?14:19));b.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);b.setTextColor(TEXT);b.setGravity(Gravity.CENTER);
   boolean special=key.equals("⇧")||key.equals("⌫")||key.equals("↵")||key.equals("?123")||key.equals("ABC");
   b.setBackground(background(special?SPECIAL:KEY));
   b.setClickable(true);
   b.setSoundEffectsEnabled(true);
   b.setOnTouchListener((view,event)->{
    if(event.getAction()==android.view.MotionEvent.ACTION_DOWN){view.setAlpha(.65f);}
    else if(event.getAction()==android.view.MotionEvent.ACTION_UP||event.getAction()==android.view.MotionEvent.ACTION_CANCEL){view.setAlpha(1f);}
    return false;
   });
   LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(51),weights==null?1:weights[i]);p.setMargins(dp(1),dp(2),dp(1),dp(2));row.addView(b,p);
   b.setOnClickListener(v->press(key));
   if(key.equals("⌫"))b.setOnLongClickListener(v->{InputConnection ic=getCurrentInputConnection();if(ic!=null){ic.deleteSurroundingText(5,0);if(recording())deletions+=5;}return true;});
  }
 }
 private void press(String key){
  InputConnection ic=getCurrentInputConnection();if(ic==null)return;
  switch(key){
   case "⇧": shifted=!shifted;render();return;
   case "?123": symbols=true;render();return;
   case "ABC": symbols=false;render();return;
   case "⌫": ic.deleteSurroundingText(1,0);if(recording())deletions++;return;
   case "↵":
    int action=getCurrentInputEditorInfo()==null?EditorInfo.IME_ACTION_NONE:(getCurrentInputEditorInfo().imeOptions&EditorInfo.IME_MASK_ACTION);
    if(action!=EditorInfo.IME_ACTION_NONE&&action!=EditorInfo.IME_ACTION_UNSPECIFIED){ic.performEditorAction(action);}else{ic.commitText("\n",1);}
    if(recording())enters++;return;
   case "☻": return; // reserved for a future emoji picker
   case "space": type(" ");return;
   default: type(shifted&&!symbols?key.toUpperCase():key);
    if(shifted&&!symbols){shifted=false;render();}
    return;
  }
 }
 private void type(String s){InputConnection ic=getCurrentInputConnection();if(ic==null)return;ic.commitText(s,1);if(recording()){if(" ".equals(s))spaces++;else chars+=s.length();}}
 @Override public void onStartInputView(EditorInfo info,boolean restarting){
  super.onStartInputView(info,restarting);started=System.currentTimeMillis();chars=deletions=spaces=enters=0;shifted=false;symbols=false;
  int variation=info.inputType&InputType.TYPE_MASK_VARIATION,klass=info.inputType&InputType.TYPE_MASK_CLASS;
  sensitive=(klass==InputType.TYPE_CLASS_TEXT&&(variation==InputType.TYPE_TEXT_VARIATION_PASSWORD||variation==InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD||variation==InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD))||(klass==InputType.TYPE_CLASS_NUMBER&&variation==InputType.TYPE_NUMBER_VARIATION_PASSWORD);
  render();
 }
 @Override public void onFinishInputView(boolean finishingInput){
  if(started>0){if(recording())SessionStore.add(this,started,System.currentTimeMillis(),chars,deletions,spaces,enters);started=0;}
  super.onFinishInputView(finishingInput);
 }
}
