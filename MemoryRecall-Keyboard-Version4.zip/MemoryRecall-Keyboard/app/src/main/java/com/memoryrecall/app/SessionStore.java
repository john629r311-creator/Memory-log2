package com.memoryrecall.app;
import android.content.*;
import java.io.*;
import java.text.*;
import java.util.*;
public final class SessionStore {
 private static final String FILE="keyboard-sessions.tsv";
 static synchronized void add(Context c,long start,long end,int chars,int deletions,int spaces,int enters){
  if(!c.getSharedPreferences("settings",Context.MODE_PRIVATE).getBoolean("consent",false))return;
  try(FileOutputStream out=c.openFileOutput(FILE,Context.MODE_APPEND)){
   out.write((start+"\t"+end+"\t"+chars+"\t"+deletions+"\t"+spaces+"\t"+enters+"\n").getBytes("UTF-8"));
  }catch(IOException ignored){}
 }
 static synchronized String between(Context c,long from,long to){
  StringBuilder b=new StringBuilder();SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);
  try(BufferedReader r=new BufferedReader(new InputStreamReader(c.openFileInput(FILE),"UTF-8"))){String line;
   while((line=r.readLine())!=null){String[] a=line.split("\t");if(a.length!=6)continue;
    long s=Long.parseLong(a[0]),e=Long.parseLong(a[1]);if(e>=from&&s<to)b.append(fmt.format(new Date(s))).append(" to ").append(fmt.format(new Date(e)))
      .append(" | characters: ").append(a[2]).append(" | backspaces: ").append(a[3])
      .append(" | spaces: ").append(a[4]).append(" | enters: ").append(a[5]).append("\n");
   }
  }catch(Exception ignored){}return b.toString();
 }
 static void clear(Context c){c.deleteFile(FILE);}
}
