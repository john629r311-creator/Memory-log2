package com.memoryrecall.app;
import android.app.usage.*;
import android.content.*;
import android.os.*;
import android.net.Uri;
import android.provider.DocumentsContract;
import java.io.*;
import java.text.*;
import java.util.*;
public final class ActivityLog {
 static final long PERIOD=30L*60*1000;
 static String report(Context ctx,long end){
  long start=end-PERIOD;
  SimpleDateFormat date=new SimpleDateFormat("EEEE, MMMM d, yyyy",Locale.US);
  SimpleDateFormat clock=new SimpleDateFormat("h:mm a",Locale.US);
  StringBuilder sb=new StringBuilder("MEMORY RECALL — ACTIVITY TIMELINE\n")
    .append(date.format(new Date(end))).append("\n")
    .append(clock.format(new Date(start))).append(" – ").append(clock.format(new Date(end))).append("\n\n");
  UsageStatsManager mgr=(UsageStatsManager)ctx.getSystemService(Context.USAGE_STATS_SERVICE);
  if(mgr==null){return sb.append("Usage Access unavailable.\n").toString();}
  UsageEvents events=mgr.queryEvents(start,end);
  UsageEvents.Event event=new UsageEvents.Event();
  // Only foreground transitions. System overlays and the launcher are not visits.
  ArrayList<Visit> visits=new ArrayList<>();
  Visit active=null;boolean screenOff=false;
  while(events.hasNextEvent()){
   events.getNextEvent(event);
   int kind=event.getEventType();long when=event.getTimeStamp();
   if(kind==UsageEvents.Event.SCREEN_NON_INTERACTIVE){
    if(active!=null){active.end=when;active=null;}
    screenOff=true;continue;
   }
   if(kind==UsageEvents.Event.SCREEN_INTERACTIVE){screenOff=false;continue;}
   if(kind!=UsageEvents.Event.ACTIVITY_RESUMED || screenOff)continue;
   String pkg=event.getPackageName();
   if(pkg==null)continue;
   if(isNoise(pkg)){if(active!=null){active.end=when;active=null;}continue;}
   if(active!=null&&pkg.equals(active.pkg))continue;
   if(active!=null){active.end=when;active=null;}
   // A brief system dialog or launcher hop should not split one visit.
   Visit previous=visits.isEmpty()?null:visits.get(visits.size()-1);
   if(previous!=null&&pkg.equals(previous.pkg)&&when-previous.end<=5000){active=previous;active.end=when;}
   else{active=new Visit(pkg,when);visits.add(active);}
  }
  // An open visit at the end of the reporting window has an uncertain end.
  if(active!=null){active.end=end;active.estimated=true;}
  sb.append("APP ACTIVITY\n\n");
  if(visits.isEmpty())sb.append("No app visits available. Check Usage Access.\n");
  for(Visit v:visits){
   long duration=Math.max(0,v.end-v.start);
   sb.append(appName(ctx,v.pkg)).append("\n")
     .append("  Opened: ").append(clock.format(new Date(v.start))).append("\n")
     .append("  Time spent: ").append(durationText(duration))
     .append(v.estimated?" (approximate; still open at report end)":" (approximate)")
     .append("\n\n");
  }
  sb.append("KEYBOARD ACTIVITY (COUNTS ONLY — NO TYPED TEXT)\n");
  String sessions=SessionStore.between(ctx,start,end);
  sb.append(sessions.isEmpty()?"No completed keyboard sessions in this period.\n":sessions);
  sb.append("\nNote: App durations are estimates from Android foreground events. ")
    .append("System dialogs and brief transitions may affect timing.\n");
  return sb.toString();
 }
 private static class Visit{
  final String pkg;final long start;long end;boolean estimated;
  Visit(String pkg,long start){this.pkg=pkg;this.start=start;this.end=start;}
 }
 private static String durationText(long ms){
  long seconds=Math.max(0,ms/1000);
  if(seconds<60)return seconds+" seconds";
  long minutes=seconds/60;long remainder=seconds%60;
  return minutes+" min"+(remainder>0?" "+remainder+" sec":"");
 }
 private static boolean isNoise(String pkg){
  return pkg.equals("com.sec.android.app.launcher")
   ||pkg.equals("com.android.systemui")
   ||pkg.equals("android")
   ||pkg.equals("com.google.android.packageinstaller")
   ||pkg.equals("com.samsung.android.packageinstaller")
   ||pkg.equals("com.google.android.permissioncontroller")
   ||pkg.equals("com.android.intentresolver");
 }
 private static String appName(Context ctx,String pkg){
  if(pkg==null||pkg.isEmpty())return "Unknown app";
  // Friendly names for common apps, even if Android limits package visibility.
  switch(pkg){
   case "com.openai.chatgpt":return "ChatGPT";
   case "com.google.android.youtube":return "YouTube";
   case "com.android.chrome":return "Chrome";
   case "com.google.android.gm":return "Gmail";
   case "com.whatsapp":return "WhatsApp";
   case "com.facebook.katana":return "Facebook";
   case "com.instagram.android":return "Instagram";
   case "com.google.android.apps.messaging":return "Google Messages";
   case "com.sec.android.app.samsungapps":return "Galaxy Store";
   case "com.google.android.documentsui":return "Android file picker";
   case "com.google.android.cellbroadcastreceiver":return "Emergency alerts";
  }
  try{
   android.content.pm.PackageManager pm=ctx.getPackageManager();
   CharSequence label=pm.getApplicationLabel(pm.getApplicationInfo(pkg,0));
   if(label!=null&&label.length()>0)return label.toString();
  }catch(Exception ignored){}
  return pkg; // Keep exact package name when the app label is unavailable.
 }
 static File save(Context ctx,long end)throws IOException {
  File dir=new File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"MemoryRecallLogs");
  if(!dir.exists()&&!dir.mkdirs())throw new IOException("Cannot create log directory");
  String name="log-"+new SimpleDateFormat("MM-dd-yy-hh-mma",Locale.US).format(new Date(end)).toLowerCase(Locale.US)+".txt";
  File file=new File(dir,name);
  try(Writer writer=new OutputStreamWriter(new FileOutputStream(file),"UTF-8")){writer.write(report(ctx,end));}
  return file;
 }
 static boolean hasChosenFolder(Context ctx){return !ctx.getSharedPreferences("settings",Context.MODE_PRIVATE).getString("log_tree","").isEmpty();}
 static void saveToChosenFolder(Context ctx,long end)throws IOException {
  String raw=ctx.getSharedPreferences("settings",Context.MODE_PRIVATE).getString("log_tree","");
  if(raw.isEmpty())throw new IOException("Choose a log folder first");
  Uri tree=Uri.parse(raw);
  String name="log-"+new SimpleDateFormat("MM-dd-yy-hh-mma",Locale.US).format(new Date(end)).toLowerCase(Locale.US)+".txt";
  Uri parent=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
  Uri doc=DocumentsContract.createDocument(ctx.getContentResolver(),parent,"text/plain",name);
  if(doc==null)throw new IOException("Cannot create file in selected folder");
  try(OutputStream out=ctx.getContentResolver().openOutputStream(doc,"wt")){
   if(out==null)throw new IOException("Cannot open selected folder for writing");
   out.write(report(ctx,end).getBytes("UTF-8"));
  }
 }
 static String saveReport(Context ctx,long end)throws IOException {
  if(hasChosenFolder(ctx)){saveToChosenFolder(ctx,end);return "Report saved to chosen folder";}
  save(ctx,end);return "Report saved to app-private folder";
 }
 static int exportExisting(Context ctx)throws IOException {
  if(!hasChosenFolder(ctx))throw new IOException("Choose a folder first");
  File dir=new File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"MemoryRecallLogs");
  File[] files=dir.listFiles();if(files==null)return 0;
  Uri tree=Uri.parse(ctx.getSharedPreferences("settings",Context.MODE_PRIVATE).getString("log_tree",""));
  Uri parent=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
  int copied=0;
  for(File file:files){if(!file.isFile()||!file.getName().endsWith(".txt"))continue;
   Uri doc=DocumentsContract.createDocument(ctx.getContentResolver(),parent,"text/plain",file.getName());
   if(doc==null)throw new IOException("Could not create "+file.getName());
   try(InputStream in=new FileInputStream(file);OutputStream out=ctx.getContentResolver().openOutputStream(doc,"wt")){
    if(out==null)throw new IOException("Cannot write "+file.getName());
    byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
   }copied++;
  }return copied;
 }
}
