package com.memoryrecall.app;
import android.app.usage.*;
import android.content.*;
import android.os.*;
import android.net.Uri;
import android.provider.DocumentsContract;
import java.io.*;
import java.text.*;
import java.util.*;
public final class ActivityLog {
 static final long PERIOD=30L*60*1000;
 static String report(Context ctx,long end){
  long start=end-PERIOD;
  SimpleDateFormat date=new SimpleDateFormat("EEEE, MMMM d, yyyy",Locale.US);
  SimpleDateFormat clock=new SimpleDateFormat("h:mm:ss a",Locale.US);
  StringBuilder sb=new StringBuilder("MEMORY RECALL — CHRONOLOGICAL ACTIVITY\n")
   .append(date.format(new Date(end))).append("\n")
   .append(clock.format(new Date(start))).append(" – ").append(clock.format(new Date(end)))
   .append("\n\nALL EVENTS IN TIME ORDER\n\n");
  UsageStatsManager mgr=(UsageStatsManager)ctx.getSystemService(Context.USAGE_STATS_SERVICE);
  if(mgr==null)return sb.append("Usage Access unavailable.\n").toString();
  UsageEvents events=mgr.queryEvents(start,end);
  UsageEvents.Event event=new UsageEvents.Event();
  ArrayList<Line> lines=new ArrayList<>();
  String foreground=null;long foregroundSince=0;
  Boolean screenOn=null;long screenSince=0;
  Boolean unlocked=null;long lockSince=0;
  while(events.hasNextEvent()){
   events.getNextEvent(event);
   int kind=event.getEventType();long when=event.getTimeStamp();
   if(kind==UsageEvents.Event.SCREEN_INTERACTIVE || kind==UsageEvents.Event.SCREEN_NON_INTERACTIVE){
    boolean on=kind==UsageEvents.Event.SCREEN_INTERACTIVE;
    if(screenOn!=null&&screenOn==on)continue;
    if(screenOn!=null)lines.add(new Line(when,"Screen "+(screenOn?"ON":"OFF")+" for "+durationText(when-screenSince)+" (observed interval)"));
    screenOn=on;screenSince=when;
    lines.add(new Line(when,"Screen turned "+(on?"ON":"OFF")));
    if(!on&&foreground!=null){lines.add(new Line(when,appName(ctx,foreground)+" left foreground — "+durationText(when-foregroundSince)+" (approximate)"));foreground=null;}
    continue;
   }
   if(kind==UsageEvents.Event.KEYGUARD_HIDDEN || kind==UsageEvents.Event.KEYGUARD_SHOWN){
    boolean nowUnlocked=kind==UsageEvents.Event.KEYGUARD_HIDDEN;
    if(unlocked!=null&&unlocked==nowUnlocked)continue;
    if(unlocked!=null)lines.add(new Line(when,(unlocked?"Unlocked":"Locked")+" state lasted "+durationText(when-lockSince)+" (observed interval)"));
    unlocked=nowUnlocked;lockSince=when;
    lines.add(new Line(when,nowUnlocked?"Phone unlocked (keyguard hidden)":"Phone locked / lock screen shown (keyguard shown)"));
    continue;
   }
   if(kind!=UsageEvents.Event.ACTIVITY_RESUMED)continue;
   String pkg=event.getPackageName();
   if(pkg==null||isNoise(pkg)||Boolean.FALSE.equals(screenOn))continue;
   if(pkg.equals(foreground))continue;
   if(foreground!=null)lines.add(new Line(when,appName(ctx,foreground)+" left foreground — "+durationText(when-foregroundSince)+" (approximate)"));
   foreground=pkg;foregroundSince=when;
   lines.add(new Line(when,appName(ctx,pkg)+" opened"));
  }
  if(foreground!=null)lines.add(new Line(end,appName(ctx,foreground)+" still in foreground at report end — "+durationText(end-foregroundSince)+" (approximate)"));
  if(screenOn!=null)lines.add(new Line(end,"Screen "+(screenOn?"ON":"OFF")+" at report end — observed for "+durationText(end-screenSince)));
  if(unlocked!=null)lines.add(new Line(end,"Phone "+(unlocked?"unlocked":"locked")+" at report end — observed for "+durationText(end-lockSince)));
  addKeyboardSessions(ctx,start,end,lines);
  Collections.sort(lines,(x,y)->Long.compare(x.time,y.time));
  if(lines.isEmpty())sb.append("No events available in this interval. Check Usage Access.\n");
  for(Line line:lines)sb.append(clock.format(new Date(line.time))).append(" — ").append(line.message).append("\n");
  sb.append("\nNotes: Times and durations come from Android usage events and may be incomplete. ")
   .append("The first event in the period may not reflect the state at the period start. ")
   .append("Keyguard events indicate lock-screen visibility, not every possible security-state change. ")
   .append("App durations are estimates, not proof that an app was closed. ")
   .append("Keyboard statistics contain counts only, never typed content or passwords.\n");
  return sb.toString();
 }
 private static class Line {
  final long time;final String message;
  Line(long time,String message){this.time=time;this.message=message;}
 }
 private static void addKeyboardSessions(Context ctx,long start,long end,ArrayList<Line> lines){
  try(BufferedReader reader=new BufferedReader(new InputStreamReader(ctx.openFileInput("keyboard-sessions.tsv"),"UTF-8"))){
   String line;
   while((line=reader.readLine())!=null){
    String[] parts=line.split("\t");if(parts.length!=6)continue;
    long begun=Long.parseLong(parts[0]),finished=Long.parseLong(parts[1]);
    if(finished<start||begun>=end)continue;
    lines.add(new Line(Math.max(start,begun),"Keyboard session started (counts only)"));
    lines.add(new Line(Math.min(end,finished),"Keyboard session ended — "+durationText(finished-begun)
     +"; characters: "+parts[2]+", backspaces: "+parts[3]+", spaces: "+parts[4]+", enters: "+parts[5]));
   }
  }catch(Exception ignored){}
 }
 private static String durationText(long ms){
  long seconds=Math.max(0,ms/1000);
  if(seconds<60)return seconds+" seconds";
  long minutes=seconds/60;long remainder=seconds%60;
  return minutes+" min"+(remainder>0?" "+remainder+" sec":"");
 }
 private static boolean isNoise(String pkg){
  return pkg.equals("com.sec.android.app.launcher")
   ||pkg.equals("com.android.systemui")
   ||pkg.equals("android")
   ||pkg.equals("com.google.android.packageinstaller")
   ||pkg.equals("com.samsung.android.packageinstaller")
   ||pkg.equals("com.google.android.permissioncontroller")
   ||pkg.equals("com.android.intentresolver");
 }
 private static String appName(Context ctx,String pkg){
  if(pkg==null||pkg.isEmpty())return "Unknown app";
  // Friendly names for common apps, even if Android limits package visibility.
  switch(pkg){
   case "com.openai.chatgpt":return "ChatGPT";
   case "com.google.android.youtube":return "YouTube";
   case "com.android.chrome":return "Chrome";
   case "com.google.android.gm":return "Gmail";
   case "com.whatsapp":return "WhatsApp";
   case "com.facebook.katana":return "Facebook";
   case "com.instagram.android":return "Instagram";
   case "com.google.android.apps.messaging":return "Google Messages";
   case "com.sec.android.app.samsungapps":return "Galaxy Store";
   case "com.google.android.documentsui":return "Android file picker";
   case "com.google.android.cellbroadcastreceiver":return "Emergency alerts";
  }
  try{
   android.content.pm.PackageManager pm=ctx.getPackageManager();
   CharSequence label=pm.getApplicationLabel(pm.getApplicationInfo(pkg,0));
   if(label!=null&&label.length()>0)return label.toString();
  }catch(Exception ignored){}
  return pkg; // Keep exact package name when the app label is unavailable.
 }
 static File save(Context ctx,long end)throws IOException {
  File dir=new File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"MemoryRecallLogs");
  if(!dir.exists()&&!dir.mkdirs())throw new IOException("Cannot create log directory");
  String name="log-"+new SimpleDateFormat("MM-dd-yy-hh-mma",Locale.US).format(new Date(end)).toLowerCase(Locale.US)+".txt";
  File file=new File(dir,name);
  try(Writer writer=new OutputStreamWriter(new FileOutputStream(file),"UTF-8")){writer.write(report(ctx,end));}
  return file;
 }
 static boolean hasChosenFolder(Context ctx){return !ctx.getSharedPreferences("settings",Context.MODE_PRIVATE).getString("log_tree","").isEmpty();}
 static void saveToChosenFolder(Context ctx,long end)throws IOException {
  String raw=ctx.getSharedPreferences("settings",Context.MODE_PRIVATE).getString("log_tree","");
  if(raw.isEmpty())throw new IOException("Choose a log folder first");
  Uri tree=Uri.parse(raw);
  String name="log-"+new SimpleDateFormat("MM-dd-yy-hh-mma",Locale.US).format(new Date(end)).toLowerCase(Locale.US)+".txt";
  Uri parent=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
  Uri doc=DocumentsContract.createDocument(ctx.getContentResolver(),parent,"text/plain",name);
  if(doc==null)throw new IOException("Cannot create file in selected folder");
  try(OutputStream out=ctx.getContentResolver().openOutputStream(doc,"wt")){
   if(out==null)throw new IOException("Cannot open selected folder for writing");
   out.write(report(ctx,end).getBytes("UTF-8"));
  }
 }
 static String saveReport(Context ctx,long end)throws IOException {
  if(hasChosenFolder(ctx)){saveToChosenFolder(ctx,end);return "Report saved to chosen folder";}
  save(ctx,end);return "Report saved to app-private folder";
 }
 static int exportExisting(Context ctx)throws IOException {
  if(!hasChosenFolder(ctx))throw new IOException("Choose a folder first");
  File dir=new File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"MemoryRecallLogs");
  File[] files=dir.listFiles();if(files==null)return 0;
  Uri tree=Uri.parse(ctx.getSharedPreferences("settings",Context.MODE_PRIVATE).getString("log_tree",""));
  Uri parent=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree));
  int copied=0;
  for(File file:files){if(!file.isFile()||!file.getName().endsWith(".txt"))continue;
   Uri doc=DocumentsContract.createDocument(ctx.getContentResolver(),parent,"text/plain",file.getName());
   if(doc==null)throw new IOException("Could not create "+file.getName());
   try(InputStream in=new FileInputStream(file);OutputStream out=ctx.getContentResolver().openOutputStream(doc,"wt")){
    if(out==null)throw new IOException("Cannot write "+file.getName());
    byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
   }copied++;
  }return copied;
 }
}
